package com.example.okhttpdemo;

import com.example.okhttpdemo.common.IBaseView;

public interface IMainView extends IBaseView {
}
